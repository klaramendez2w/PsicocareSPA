import { Component, OnInit } from '@angular/core';
import { User } from '../Modelos/User';
import { UsuarioService } from '../services/usuario.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validator, Validators } from '@angular/forms';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  // private _uid: number;
  currentUser: User;
  // loginForm: FormGroup;
  user = { email: "", pass: "" };

  constructor(private _usersServices: UsuarioService,
    private _router: Router,
    // private _route: ActivatedRoute,
    // private formBuilder: FormBuilder,
  ) { }

  ngOnInit() {
    //Esto es para traer datos desde el id, no esta siendo utilizado
    // this._route.paramMap.subscribe(params =>
    //   this._uid = +params.get('uid'))
    // this._usersServices.getUserFromApiByUid(this._uid).subscribe(res => this.user = res);
    //---------//

    //Esto es para usar el login de internet
    // this.loginForm = this.formBuilder.group({
    //   email: ['', [ Validators.required ]],
    //   password: ['', [ Validators.required ]]
    // })
    //------------------//

    // onClick(uid: number){
    //   this._usersServices.getUserFromApiByUid(uid).subscribe(res =>{ 
    //     // this.currentActivity = res
    //     this._router.navigate(['homeactivities',uid]);
    //   }
    //     );
    //   console.log(uid);

  }
  acceder() {
    this._usersServices.login(this.user.email, this.user.pass).subscribe(respuesta => {
      
      localStorage.setItem('token', respuesta.id);
      if (respuesta.email == this.user.email && respuesta.password == this.user.pass) {
        this._router.navigate(['/homeactivities'])
      }


      console.log(this.user.email)
      console.log(respuesta.message);
    })
  }

//---------------------------------------//
//Este login es de internet
    // acceder() {

    //  
    //   this._usersServices.login(this.loginForm.value).subscribe(res => {
    //     console.log(res);

    //     if (res.status == 200 && res.result == true) {
    //       localStorage.setItem('email', this.loginForm.value.email);
    //       this._router.navigate(['/homeactivities'])
    //     }

    //   })
    // }

}
